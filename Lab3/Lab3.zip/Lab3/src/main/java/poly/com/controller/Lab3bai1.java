package poly.com.controller;

import poly.com.model.Country;
import poly.com.model.CountryData;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/lab3bai1")
public class Lab3bai1 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	// setAttribute dùng để truyền dữ liệu servlet sang jsp. "tenThuocTinh", giaTri
	// getCountries 1 method static
	req.setAttribute("countries", CountryData.getCountries());
	req.getRequestDispatcher("lab3bai1.jsp").forward(req, resp);
    }
}
