package poly.com.controller;

import java.io.IOException;
import java.util.ArrayList;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import poly.com.model.CartItem;

@WebServlet("/updatecart")
public class UpdateCart extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name");
        String action = req.getParameter("action");

        HttpSession session = req.getSession();
        ArrayList<CartItem> cart = (ArrayList<CartItem>) session.getAttribute("cart");
        if (cart != null) {
            CartItem toRemove = null;
            for (CartItem ci : cart) {
                if (ci.getItem().getName().equalsIgnoreCase(name)) {
                    switch (action) {
                        case "increase":
                            ci.setQuantity(ci.getQuantity() + 1);
                            break;
                        case "decrease":
                            ci.setQuantity(ci.getQuantity() - 1);
                            if (ci.getQuantity() <= 0) toRemove = ci;
                            break;
                        case "remove":
                            toRemove = ci;
                            break;
                    }
                    break;
                }
            }
            if (toRemove != null) cart.remove(toRemove);
        }

        session.setAttribute("cart", cart);
        resp.sendRedirect("cart.jsp");
    }
}
