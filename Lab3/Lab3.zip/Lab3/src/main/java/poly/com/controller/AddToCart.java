package poly.com.controller;

import java.io.IOException;
import java.util.ArrayList;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import poly.com.model.CartItem;
import poly.com.model.ItemData;

@WebServlet("/addtocart")
public class AddToCart extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	String name = req.getParameter("id");

	ArrayList<ItemData> items = (ArrayList<ItemData>) getServletContext().getAttribute("items");

	ItemData selected = null;
	for (ItemData x : items) {
	    if (x.getName().equalsIgnoreCase(name)) {
		selected = x;
		break;
	    }
	}

	if (selected == null) {
	    resp.sendRedirect("lab3bai5");
	    return;
	}
	//xử lý giở hàng
	HttpSession session = req.getSession();
	ArrayList<CartItem> cart = (ArrayList<CartItem>) session.getAttribute("cart");
	if (cart == null)
	    cart = new ArrayList<>();

	boolean found = false;
	for (CartItem ci : cart) {
	    if (ci.getItem().getName().equalsIgnoreCase(selected.getName())) {
		ci.setQuantity(ci.getQuantity() + 1); // tăng số lượng
		found = true;
		break;
	    }
	}
	if (!found) {
	    cart.add(new CartItem(selected, 1));
	}

	session.setAttribute("cart", cart);
	session.setAttribute("message", selected.getName() + " đã được thêm vào giỏ hàng!");

	resp.sendRedirect("lab3bai5");
    }
}
