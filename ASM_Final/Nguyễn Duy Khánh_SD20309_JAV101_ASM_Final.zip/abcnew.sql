﻿-- 1. Tạo database
IF DB_ID(N'ABCNews') IS NULL
BEGIN
    CREATE DATABASE ABCNews;
END
GO

USE ABCNews;
GO

-- 2. Bảng Users
IF OBJECT_ID('dbo.Users', 'U') IS NOT NULL DROP TABLE dbo.Users;
CREATE TABLE dbo.Users (
    Id VARCHAR(50) PRIMARY KEY,
    Password VARCHAR(255) NOT NULL, -- demo: plain text (=> production: hash)
    Fullname NVARCHAR(200),
    Birthday DATE NULL,
    Gender BIT NULL,
    Mobile VARCHAR(20),
    Email VARCHAR(255),
    Role BIT NOT NULL -- 1 = admin, 0 = reporter
);
GO

-- 3. Bảng Categories
IF OBJECT_ID('dbo.Categories', 'U') IS NOT NULL DROP TABLE dbo.Categories;
CREATE TABLE dbo.Categories (
    Id VARCHAR(50) PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL
);
GO

-- 4. Bảng News
IF OBJECT_ID('dbo.News', 'U') IS NOT NULL DROP TABLE dbo.News;
CREATE TABLE dbo.News (
    Id VARCHAR(50) PRIMARY KEY,
    Title NVARCHAR(500) NOT NULL,
    Summary NVARCHAR(1000) NULL,
    Content NVARCHAR(MAX) NOT NULL,
    Image NVARCHAR(500) NULL,
    PostedDate DATETIME DEFAULT GETDATE(),
    Author VARCHAR(50) NULL,
    ViewCount INT DEFAULT 0,
    CategoryId VARCHAR(50) NULL,
    Home BIT DEFAULT 0,
    CONSTRAINT FK_News_Author FOREIGN KEY (Author) REFERENCES dbo.Users(Id),
    CONSTRAINT FK_News_Category FOREIGN KEY (CategoryId) REFERENCES dbo.Categories(Id)
);
GO

-- 5. Bảng Newsletters
IF OBJECT_ID('dbo.Newsletters', 'U') IS NOT NULL DROP TABLE dbo.Newsletters;
CREATE TABLE dbo.Newsletters (
    Email VARCHAR(255) PRIMARY KEY,
    Enabled BIT DEFAULT 1,
    SubscribedDate DATETIME DEFAULT GETDATE()
);
GO

INSERT INTO Users VALUES
('admin', '123', N'Quản trị viên', NULL, 1, NULL, 'admin@test.com', 1),
('rep1', '123', N'Phóng viên 1', NULL, 1, NULL, 'pv1@test.com', 0);

INSERT INTO Categories VALUES
('ct', N'Chính trị'),
('kt', N'Kinh tế'),
('gt', N'Giải trí');

INSERT INTO News VALUES
('n1', N'Tin demo 1', N'Tóm tắt ngắn', N'Nội dung bài viết mẫu…', NULL, GETDATE(), 'rep1', 5, 'ct', 1),
('n2', N'Tin demo 2', N'Tóm tắt ngắn', N'Nội dung bài viết mẫu…', NULL, GETDATE(), 'rep1', 2, 'kt', 0),
('n3', N'Tin demo 3', N'Tóm tắt ngắn', N'Nội dung bài viết mẫu…', NULL, GETDATE(), 'rep1', 1, 'gt', 0);

INSERT INTO Newsletters (Email, Enabled) VALUES
('demo1@test.com', 1),
('demo2@test.com', 1);


SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE';
SELECT * FROM dbo.Users;
SELECT * FROM dbo.Categories;
SELECT TOP 10 * FROM dbo.News ORDER BY PostedDate DESC;
SELECT * FROM dbo.Newsletters;

SELECT dp.name, dp.type_desc, p.permission_name
FROM sys.database_permissions p
JOIN sys.database_principals dp ON p.grantee_principal_id = dp.principal_id
WHERE dp.name = 'abcnews_user';

USE ABCNews;
GO

USE ABCNews;
GO

-- Đặt 'Tin demo 1' (với id='n1') làm tin trang nhất
UPDATE News
SET Home = 1
WHERE Id = 'n1';
GO

-- KIỂM TRA LẠI:
SELECT Id, Title, Home FROM News WHERE Id = 'n1';
-- (Kết quả của lệnh SELECT này phải thấy cột Home = 1)