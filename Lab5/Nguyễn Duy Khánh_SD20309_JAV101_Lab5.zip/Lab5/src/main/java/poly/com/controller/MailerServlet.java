package poly.com.controller;

import poly.com.util.Mailer;
import jakarta.mail.MessagingException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.IOException;

/**
 * Servlet cho Bài 2: nhận dữ liệu từ form gửi mail và gọi util Mailer.
 */
@WebServlet(urlPatterns = "/mailer")
@MultipartConfig(maxFileSize = 5 * 1024 * 1024) // 5MB
public class MailerServlet extends HttpServlet {

    /** JSP hiển thị form gửi mail. */
    private static final String VIEW = "/WEB-INF/views/mail-form.jsp";

    /**
     * Render form khi truy cập GET.
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("fromAddress", Mailer.getConfiguredSender());
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    /**
     * Nhận dữ liệu form và gọi Mailer.send.
     * Nếu có lỗi MessagingException sẽ trả thông báo lỗi ra UI.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String from = Mailer.getConfiguredSender();
        String to = req.getParameter("to");
        String subject = req.getParameter("subject");
        String body = req.getParameter("body");

        try {
            Mailer.Attachment attachment = buildAttachment(req.getPart("attachment"));
            Mailer.send(from, to, subject, body, attachment);
            req.setAttribute("message", "Đã gửi email thành công!");
            req.setAttribute("alertType", "success");
        } catch (MessagingException ex) {
            req.setAttribute("message", "Gửi email thất bại: " + ex.getMessage());
            req.setAttribute("alertType", "danger");
        }

        req.setAttribute("fromAddress", from);
        req.setAttribute("to", to);
        req.setAttribute("subject", subject);
        req.setAttribute("body", body);
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    private Mailer.Attachment buildAttachment(Part part) throws IOException {
        if (part == null || part.getSize() == 0) {
            return null;
        }
        byte[] data = part.getInputStream().readAllBytes();
        return new Mailer.Attachment(part.getSubmittedFileName(), part.getContentType(), data);
    }
}

