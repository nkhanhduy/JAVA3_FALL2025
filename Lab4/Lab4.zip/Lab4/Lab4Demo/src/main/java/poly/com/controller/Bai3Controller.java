package poly.com.controller;

import java.io.IOException;
import java.util.Arrays;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/register")
public class Bai3Controller extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	 req.getRequestDispatcher("/register.jsp").forward(req, resp);
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	String username = req.getParameter("username");
    String password = req.getParameter("password");
    String email    = req.getParameter("email");
    String gender   = req.getParameter("gender");

    // tham số đa trị (checkbox)
    String[] hobbies = req.getParameterValues("hobby");

    // kiểm tra và in ra console (server logs)
    System.out.println("Register info:");
    System.out.println("username=" + username);
    System.out.println("password=" + password);
    System.out.println("email=" + email);
    System.out.println("gender=" + gender);
    System.out.println("hobbies=" + (hobbies == null ? "none" : Arrays.toString(hobbies)));

    req.setAttribute("message", "Đã nhận dữ liệu. Check server log để xem chi tiết.");
    req.getRequestDispatcher("/register.jsp").forward(req, resp);

	}
}
