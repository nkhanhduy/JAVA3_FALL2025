package poly.com.util;

import java.sql.*;

public class Jdbc {
    static String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    static String dburl = "jdbc:sqlserver://localhost;database=HRM;encrypt=true;trustServerCertificate=true";
    static String username = "sa";
    static String password = "123456";
    
    static {
        try {
            // Nạp driver
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    
    /** Mở kết nối */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dburl, username, password);
    }
    
    /** Thao tác dữ liệu với PreparedStatement */
    public static int executeUpdate(String sql, Object... values) throws SQLException {
        PreparedStatement stmt = createPreStmt(sql, values);
        int result = stmt.executeUpdate();
        Connection conn = stmt.getConnection();
        stmt.close();
        conn.close();
        return result;
    }
    
    /** Truy vấn dữ liệu với PreparedStatement */
    public static ResultSet executeQuery(String sql, Object... values) throws SQLException {
        PreparedStatement stmt = createPreStmt(sql, values);
        return stmt.executeQuery();
    }
    
    /** Tạo PreparedStatement làm việc với SQL hoặc PROC */
    private static PreparedStatement createPreStmt(String sql, Object... values) throws SQLException {
        Connection connection = getConnection();
        PreparedStatement stmt = null;
        if (sql.trim().startsWith("{")) {
            stmt = connection.prepareCall(sql);
        } else {
            stmt = connection.prepareStatement(sql);
        }
        for (int i = 0; i < values.length; i++) {
            stmt.setObject(i + 1, values[i]);
        }
        return stmt;
    }
    
    /** Thao tác dữ liệu với CallableStatement */
    public static int executeUpdateCallable(String sql, Object... values) throws SQLException {
        Connection connection = getConnection();
        CallableStatement statement = connection.prepareCall(sql);
        try {
            for (int i = 0; i < values.length; i++) {
                statement.setObject(i + 1, values[i]);
            }
            return statement.executeUpdate();
        } finally {
            statement.close();
            connection.close();
        }
    }
    
    /** Truy vấn dữ liệu với CallableStatement */
    public static ResultSet executeQueryCallable(String sql, Object... values) throws SQLException {
        Connection connection = getConnection();
        CallableStatement statement = connection.prepareCall(sql);
        for (int i = 0; i < values.length; i++) {
            statement.setObject(i + 1, values[i]);
        }
        // Lưu ý: Connection và Statement sẽ được đóng khi ResultSet được đóng
        return statement.executeQuery();
    }
}

