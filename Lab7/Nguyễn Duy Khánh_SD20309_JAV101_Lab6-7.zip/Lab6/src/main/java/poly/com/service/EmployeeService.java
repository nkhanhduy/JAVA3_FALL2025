package poly.com.service;

import poly.com.dao.EmployeeDAO;
import poly.com.model.Employee;

import java.sql.SQLException;
import java.util.List;

public class EmployeeService {
    private EmployeeDAO dao = new EmployeeDAO();
    
    public List<Employee> findAll() {
        try {
            return dao.findAll();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public Employee findById(String id) {
        try {
            return dao.findById(id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public boolean insert(Employee emp) {
        try {
            return dao.insert(emp) > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public boolean update(Employee emp) {
        try {
            return dao.update(emp) > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public boolean delete(String id) {
        try {
            return dao.delete(id) > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public List<Employee> findByDepartmentId(String departmentId) {
        try {
            return dao.findByDepartmentId(departmentId);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}

