package poly.com.dao;

import poly.com.model.Department;
import poly.com.util.Jdbc;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DepartmentDAO {
    
    /** Truy vấn tất cả departments */
    public List<Department> findAll() throws SQLException {
        List<Department> list = new ArrayList<>();
        String sql = "SELECT * FROM Departments";
        try (ResultSet rs = Jdbc.executeQuery(sql)) {
            while (rs.next()) {
                Department dept = new Department();
                dept.setId(rs.getString("Id"));
                dept.setName(rs.getString("Name"));
                dept.setDescription(rs.getString("Description"));
                list.add(dept);
            }
        }
        return list;
    }
    
    /** Truy vấn theo khóa chính */
    public Department findById(String id) throws SQLException {
        String sql = "SELECT * FROM Departments WHERE Id = ?";
        try (ResultSet rs = Jdbc.executeQuery(sql, id)) {
            if (rs.next()) {
                Department dept = new Department();
                dept.setId(rs.getString("Id"));
                dept.setName(rs.getString("Name"));
                dept.setDescription(rs.getString("Description"));
                return dept;
            }
        }
        return null;
    }
    
    /** Thêm mới */
    public int insert(Department dept) throws SQLException {
        String sql = "INSERT INTO Departments(Id, Name, Description) VALUES(?, ?, ?)";
        return Jdbc.executeUpdate(sql, dept.getId(), dept.getName(), dept.getDescription());
    }
    
    /** Cập nhật theo khóa chính */
    public int update(Department dept) throws SQLException {
        String sql = "UPDATE Departments SET Name = ?, Description = ? WHERE Id = ?";
        return Jdbc.executeUpdate(sql, dept.getName(), dept.getDescription(), dept.getId());
    }
    
    /** Xóa theo khóa chính */
    public int delete(String id) throws SQLException {
        String sql = "DELETE FROM Departments WHERE Id = ?";
        return Jdbc.executeUpdate(sql, id);
    }
    
    /** Sử dụng CallableStatement - Truy vấn tất cả */
    public List<Department> findAllCallable() throws SQLException {
        List<Department> list = new ArrayList<>();
        String sql = "{CALL spSelectAll()}";
        try (ResultSet rs = Jdbc.executeQueryCallable(sql)) {
            while (rs.next()) {
                Department dept = new Department();
                dept.setId(rs.getString("Id"));
                dept.setName(rs.getString("Name"));
                dept.setDescription(rs.getString("Description"));
                list.add(dept);
            }
        }
        return list;
    }
    
    /** Sử dụng CallableStatement - Truy vấn theo khóa chính */
    public Department findByIdCallable(String id) throws SQLException {
        String sql = "{CALL spSelectById(?)}";
        try (ResultSet rs = Jdbc.executeQueryCallable(sql, id)) {
            if (rs.next()) {
                Department dept = new Department();
                dept.setId(rs.getString("Id"));
                dept.setName(rs.getString("Name"));
                dept.setDescription(rs.getString("Description"));
                return dept;
            }
        }
        return null;
    }
    
    /** Sử dụng CallableStatement - Thêm mới */
    public int insertCallable(Department dept) throws SQLException {
        String sql = "{CALL spInsert(?, ?, ?)}";
        return Jdbc.executeUpdateCallable(sql, dept.getId(), dept.getName(), dept.getDescription());
    }
    
    /** Sử dụng CallableStatement - Cập nhật */
    public int updateCallable(Department dept) throws SQLException {
        String sql = "{CALL spUpdate(?, ?, ?)}";
        return Jdbc.executeUpdateCallable(sql, dept.getId(), dept.getName(), dept.getDescription());
    }
    
    /** Sử dụng CallableStatement - Xóa */
    public int deleteCallable(String id) throws SQLException {
        String sql = "{CALL spDeleteById(?)}";
        return Jdbc.executeUpdateCallable(sql, id);
    }
}

