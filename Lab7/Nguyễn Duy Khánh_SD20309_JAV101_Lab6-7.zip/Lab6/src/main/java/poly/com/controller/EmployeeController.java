package poly.com.controller;

import poly.com.model.Employee;
import poly.com.service.DepartmentService;
import poly.com.service.EmployeeService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.Part;

@WebServlet("/employees")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
                 maxFileSize = 1024 * 1024 * 10,        // 10MB
                 maxRequestSize = 1024 * 1024 * 50)     // 50MB
public class EmployeeController extends HttpServlet {
    private EmployeeService employeeService = new EmployeeService();
    private DepartmentService departmentService = new DepartmentService();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }
        
        switch (action) {
            case "list":
                listEmployees(request, response);
                break;
            case "create":
                showCreateForm(request, response);
                break;
            case "edit":
                showEditForm(request, response);
                break;
            case "view":
                showEmployeeProfile(request, response);
                break;
            case "delete":
                deleteEmployee(request, response);
                break;
            default:
                listEmployees(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if ("create".equals(action)) {
            createEmployee(request, response);
        } else if ("update".equals(action)) {
            updateEmployee(request, response);
        } else {
            listEmployees(request, response);
        }
    }
    
    private void listEmployees(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.setAttribute("employees", employeeService.findAll());
        request.setAttribute("departments", departmentService.findAll());
        request.getRequestDispatcher("/WEB-INF/views/employees/list.jsp").forward(request, response);
    }
    
    private void showCreateForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.setAttribute("departments", departmentService.findAll());
        request.getRequestDispatcher("/WEB-INF/views/employees/create.jsp").forward(request, response);
    }
    
    private void showEditForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String id = request.getParameter("id");
        request.setAttribute("employee", employeeService.findById(id));
        request.setAttribute("departments", departmentService.findAll());
        request.getRequestDispatcher("/WEB-INF/views/employees/edit.jsp").forward(request, response);
    }
    
    private void showEmployeeProfile(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String id = request.getParameter("id");
        request.setAttribute("employee", employeeService.findById(id));
        request.setAttribute("departments", departmentService.findAll());
        request.getRequestDispatcher("/WEB-INF/views/employees/view.jsp").forward(request, response);
    }
    
    private void updateEmployee(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, ServletException {
        Employee emp = new Employee();
        emp.setId(request.getParameter("id"));
        emp.setPassword(request.getParameter("password"));
        emp.setFullname(request.getParameter("fullname"));
        
        // Xử lý upload file ảnh
        Part photoPart = request.getPart("photoFile");
        String photoFileName = request.getParameter("photo");
        
        if (photoPart != null && photoPart.getSize() > 0) {
            String fileName = getFileName(photoPart);
            if (fileName != null && !fileName.isEmpty()) {
                // Lưu file vào thư mục img
                String uploadPath = getServletContext().getRealPath("/img");
                Path uploadDir = Paths.get(uploadPath);
                if (!Files.exists(uploadDir)) {
                    Files.createDirectories(uploadDir);
                }
                
                Path filePath = uploadDir.resolve(fileName);
                try (InputStream inputStream = photoPart.getInputStream()) {
                    Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
                }
                photoFileName = fileName;
            }
        }
        
        emp.setPhoto(photoFileName);
        emp.setGender("true".equals(request.getParameter("gender")) || "1".equals(request.getParameter("gender")));
        emp.setBirthday(LocalDate.parse(request.getParameter("birthday")));
        emp.setSalary(Double.parseDouble(request.getParameter("salary")));
        emp.setDepartmentId(request.getParameter("departmentId"));
        
        employeeService.update(emp);
        response.sendRedirect("employees?action=list");
    }
    
    private void createEmployee(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, ServletException {
        Employee emp = new Employee();
        emp.setId(request.getParameter("id"));
        emp.setPassword(request.getParameter("password"));
        emp.setFullname(request.getParameter("fullname"));
        
        // Xử lý upload file ảnh
        Part photoPart = request.getPart("photoFile");
        String photoFileName = request.getParameter("photo");
        
        if (photoPart != null && photoPart.getSize() > 0) {
            String fileName = getFileName(photoPart);
            if (fileName != null && !fileName.isEmpty()) {
                // Lưu file vào thư mục img
                String uploadPath = getServletContext().getRealPath("/img");
                Path uploadDir = Paths.get(uploadPath);
                if (!Files.exists(uploadDir)) {
                    Files.createDirectories(uploadDir);
                }
                
                Path filePath = uploadDir.resolve(fileName);
                try (InputStream inputStream = photoPart.getInputStream()) {
                    Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
                }
                photoFileName = fileName;
            }
        }
        
        emp.setPhoto(photoFileName);
        emp.setGender("true".equals(request.getParameter("gender")) || "1".equals(request.getParameter("gender")));
        emp.setBirthday(LocalDate.parse(request.getParameter("birthday")));
        emp.setSalary(Double.parseDouble(request.getParameter("salary")));
        emp.setDepartmentId(request.getParameter("departmentId"));
        
        employeeService.insert(emp);
        response.sendRedirect("employees?action=list");
    }
    
    private String getFileName(Part part) {
        String contentDisposition = part.getHeader("content-disposition");
        String[] tokens = contentDisposition.split(";");
        for (String token : tokens) {
            if (token.trim().startsWith("filename")) {
                return token.substring(token.indexOf("=") + 2, token.length() - 1);
            }
        }
        return null;
    }
    
    private void deleteEmployee(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        String id = request.getParameter("id");
        employeeService.delete(id);
        response.sendRedirect("employees?action=list");
    }
}

