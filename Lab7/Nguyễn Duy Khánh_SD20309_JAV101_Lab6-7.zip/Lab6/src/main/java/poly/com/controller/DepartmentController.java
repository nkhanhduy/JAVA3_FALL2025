package poly.com.controller;

import poly.com.model.Department;
import poly.com.service.DepartmentService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/departments")
public class DepartmentController extends HttpServlet {
    private DepartmentService service = new DepartmentService();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }
        
        switch (action) {
            case "list":
                listDepartments(request, response);
                break;
            case "create":
                showCreateForm(request, response);
                break;
            case "edit":
                showEditForm(request, response);
                break;
            case "delete":
                deleteDepartment(request, response);
                break;
            default:
                listDepartments(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if ("create".equals(action)) {
            createDepartment(request, response);
        } else if ("update".equals(action)) {
            updateDepartment(request, response);
        } else {
            listDepartments(request, response);
        }
    }
    
    private void listDepartments(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        List<Department> departments = service.findAll();
        request.setAttribute("departments", departments);
        request.getRequestDispatcher("/WEB-INF/views/departments/list.jsp").forward(request, response);
    }
    
    private void showCreateForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/views/departments/create.jsp").forward(request, response);
    }
    
    private void showEditForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String id = request.getParameter("id");
        Department dept = service.findById(id);
        request.setAttribute("department", dept);
        request.getRequestDispatcher("/WEB-INF/views/departments/edit.jsp").forward(request, response);
    }
    
    private void createDepartment(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        Department dept = new Department();
        dept.setId(request.getParameter("id"));
        dept.setName(request.getParameter("name"));
        dept.setDescription(request.getParameter("description"));
        
        service.insert(dept);
        response.sendRedirect("departments?action=list");
    }
    
    private void updateDepartment(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        Department dept = new Department();
        dept.setId(request.getParameter("id"));
        dept.setName(request.getParameter("name"));
        dept.setDescription(request.getParameter("description"));
        
        service.update(dept);
        response.sendRedirect("departments?action=list");
    }
    
    private void deleteDepartment(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        String id = request.getParameter("id");
        service.delete(id);
        response.sendRedirect("departments?action=list");
    }
}

