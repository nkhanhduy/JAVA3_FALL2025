package poly.com.dao;

import poly.com.model.Department;
import java.util.List;

/**
 * Interface DepartmentDAO theo Lab7
 */
public interface DepartmentDAOInterface {
    /** Truy vấn tất cả */
    List<Department> findAll();
    
    /** Truy vấn theo mã */
    Department findById(String id);
    
    /** Thêm mới */
    void create(Department item);
    
    /** Cập nhật */
    void update(Department item);
    
    /** Xóa theo mã */
    void deleteById(String id);
}

