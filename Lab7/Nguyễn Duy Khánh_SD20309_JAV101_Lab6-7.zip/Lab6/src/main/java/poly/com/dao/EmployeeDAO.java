package poly.com.dao;

import poly.com.model.Employee;
import poly.com.util.Jdbc;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {
    
    /** Truy vấn tất cả employees */
    public List<Employee> findAll() throws SQLException {
        List<Employee> list = new ArrayList<>();
        String sql = "SELECT * FROM Employees";
        try (ResultSet rs = Jdbc.executeQuery(sql)) {
            while (rs.next()) {
                Employee emp = new Employee();
                emp.setId(rs.getString("Id"));
                emp.setPassword(rs.getString("Password"));
                emp.setFullname(rs.getString("Fullname"));
                emp.setPhoto(rs.getString("Photo"));
                emp.setGender(rs.getBoolean("Gender"));
                Date birthday = rs.getDate("Birthday");
                if (birthday != null) {
                    emp.setBirthday(birthday.toLocalDate());
                }
                emp.setSalary(rs.getDouble("Salary"));
                emp.setDepartmentId(rs.getString("DepartmentId"));
                list.add(emp);
            }
        }
        return list;
    }
    
    /** Truy vấn theo khóa chính */
    public Employee findById(String id) throws SQLException {
        String sql = "SELECT * FROM Employees WHERE Id = ?";
        try (ResultSet rs = Jdbc.executeQuery(sql, id)) {
            if (rs.next()) {
                Employee emp = new Employee();
                emp.setId(rs.getString("Id"));
                emp.setPassword(rs.getString("Password"));
                emp.setFullname(rs.getString("Fullname"));
                emp.setPhoto(rs.getString("Photo"));
                emp.setGender(rs.getBoolean("Gender"));
                Date birthday = rs.getDate("Birthday");
                if (birthday != null) {
                    emp.setBirthday(birthday.toLocalDate());
                }
                emp.setSalary(rs.getDouble("Salary"));
                emp.setDepartmentId(rs.getString("DepartmentId"));
                return emp;
            }
        }
        return null;
    }
    
    /** Thêm mới */
    public int insert(Employee emp) throws SQLException {
        String sql = "INSERT INTO Employees(Id, Password, Fullname, Photo, Gender, Birthday, Salary, DepartmentId) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
        return Jdbc.executeUpdate(sql, 
            emp.getId(), 
            emp.getPassword(), 
            emp.getFullname(), 
            emp.getPhoto(), 
            emp.isGender(), 
            Date.valueOf(emp.getBirthday()), 
            emp.getSalary(), 
            emp.getDepartmentId());
    }
    
    /** Cập nhật theo khóa chính */
    public int update(Employee emp) throws SQLException {
        String sql = "UPDATE Employees SET Password = ?, Fullname = ?, Photo = ?, Gender = ?, Birthday = ?, Salary = ?, DepartmentId = ? WHERE Id = ?";
        return Jdbc.executeUpdate(sql, 
            emp.getPassword(), 
            emp.getFullname(), 
            emp.getPhoto(), 
            emp.isGender(), 
            Date.valueOf(emp.getBirthday()), 
            emp.getSalary(), 
            emp.getDepartmentId(),
            emp.getId());
    }
    
    /** Xóa theo khóa chính */
    public int delete(String id) throws SQLException {
        String sql = "DELETE FROM Employees WHERE Id = ?";
        return Jdbc.executeUpdate(sql, id);
    }
    
    /** Truy vấn theo DepartmentId */
    public List<Employee> findByDepartmentId(String departmentId) throws SQLException {
        List<Employee> list = new ArrayList<>();
        String sql = "SELECT * FROM Employees WHERE DepartmentId = ?";
        try (ResultSet rs = Jdbc.executeQuery(sql, departmentId)) {
            while (rs.next()) {
                Employee emp = new Employee();
                emp.setId(rs.getString("Id"));
                emp.setPassword(rs.getString("Password"));
                emp.setFullname(rs.getString("Fullname"));
                emp.setPhoto(rs.getString("Photo"));
                emp.setGender(rs.getBoolean("Gender"));
                Date birthday = rs.getDate("Birthday");
                if (birthday != null) {
                    emp.setBirthday(birthday.toLocalDate());
                }
                emp.setSalary(rs.getDouble("Salary"));
                emp.setDepartmentId(rs.getString("DepartmentId"));
                list.add(emp);
            }
        }
        return list;
    }
}

