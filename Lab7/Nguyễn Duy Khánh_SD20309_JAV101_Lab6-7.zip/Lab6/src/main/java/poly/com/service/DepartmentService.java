package poly.com.service;

import poly.com.dao.DepartmentDAO;
import poly.com.model.Department;

import java.sql.SQLException;
import java.util.List;

public class DepartmentService {
    private DepartmentDAO dao = new DepartmentDAO();
    
    public List<Department> findAll() {
        try {
            return dao.findAll();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public Department findById(String id) {
        try {
            return dao.findById(id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public boolean insert(Department dept) {
        try {
            return dao.insert(dept) > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public boolean update(Department dept) {
        try {
            return dao.update(dept) > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public boolean delete(String id) {
        try {
            return dao.delete(id) > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}

