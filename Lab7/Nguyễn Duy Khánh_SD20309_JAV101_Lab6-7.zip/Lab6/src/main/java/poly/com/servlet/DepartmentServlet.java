package poly.com.servlet;

import poly.com.dao.DepartmentDAOInterface;
import poly.com.dao.DepartmentDAOImpl;
import poly.com.model.Department;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.beanutils.BeanUtils;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

/**
 * DepartmentServlet theo Lab7
 * Xử lý CRUD Department với BeanUtils
 */
@WebServlet({
    "/department/index",
    "/department/edit/*",
    "/department/create",
    "/department/update",
    "/department/delete",
    "/department/reset"
})
public class DepartmentServlet extends HttpServlet {
    
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        Department form = new Department();
        try {
            BeanUtils.populate(form, req.getParameterMap());
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }
        
        DepartmentDAOInterface dao = new DepartmentDAOImpl();
        String path = req.getServletPath();
        String pathInfo = req.getPathInfo();
        
        try {
            if (path.contains("edit") && pathInfo != null && pathInfo.length() > 1) {
                // Xử lý edit với path info: /department/edit/IT
                String id = pathInfo.substring(1);
                form = dao.findById(id);
            } else if (path.contains("create")) {
                // Xử lý create
                if (form.getId() != null && !form.getId().trim().isEmpty()) {
                    dao.create(form);
                    form = new Department();
                }
            } else if (path.contains("update")) {
                // Xử lý update
                if (form.getId() != null && !form.getId().trim().isEmpty()) {
                    dao.update(form);
                }
            } else if (path.contains("delete")) {
                // Xử lý delete
                if (form.getId() != null && !form.getId().trim().isEmpty()) {
                    dao.deleteById(form.getId());
                }
                form = new Department();
            } else if (path.contains("reset")) {
                // Reset form
                form = new Department();
            }
        } catch (Exception e) {
            req.setAttribute("error", "Error: " + e.getMessage());
            e.printStackTrace();
        }
        
        req.setAttribute("item", form);
        List<Department> list = dao.findAll();
        req.setAttribute("list", list);
        req.getRequestDispatcher("/views/department.jsp").forward(req, resp);
    }
}

