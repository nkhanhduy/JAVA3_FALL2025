# HRM System - Lab 6

Hệ thống quản lý nhân sự (HRM) được xây dựng theo mô hình 3 lớp với JDBC, sử dụng JDK 17 và Tomcat 10.1.

## Cấu trúc Project

### Mô hình 3 lớp (3-Tier Architecture)

1. **Presentation Layer (View/Controller)**
   - `src/main/webapp/` - JSP views với Bootstrap 5
   - `src/main/java/poly/com/controller/` - Servlets (Controllers)

2. **Business Logic Layer (Service)**
   - `src/main/java/poly/com/service/` - Business logic services

3. **Data Access Layer (DAO)**
   - `src/main/java/poly/com/dao/` - Data Access Objects

### Model
- `src/main/java/poly/com/model/` - Entity classes (Department, Employee)

### Utilities
- `src/main/java/poly/com/util/Jdbc.java` - JDBC utility class với PreparedStatement và CallableStatement

## Yêu cầu

- JDK 17
- Apache Tomcat 10.1
- SQL Server (với SQL Server JDBC Driver)
- Maven 3.x

## Cài đặt Database

1. Chạy script SQL trong file `database/HRM_Database.sql` để tạo database và các bảng:
   - `Departments` - Bảng phòng ban
   - `Employees` - Bảng nhân viên
   - Các stored procedures cho Departments

2. Cấu hình thông tin kết nối trong `src/main/java/poly/com/util/Jdbc.java`:
   ```java
   static String dburl = "jdbc:sqlserver://localhost;database=HRM";
   static String username = "sa";
   static String password = "123456";
   ```

## Cấu hình Project

1. Import project vào Eclipse
2. Đảm bảo Tomcat 10.1 được cấu hình
3. Build project với Maven:
   ```bash
   mvn clean install
   ```
4. Deploy lên Tomcat và chạy

## Tính năng

### Quản lý Phòng Ban (Departments)
- Xem danh sách phòng ban
- Thêm mới phòng ban
- Sửa thông tin phòng ban
- Xóa phòng ban
- Hỗ trợ PreparedStatement và CallableStatement

### Quản lý Nhân Viên (Employees)
- Xem danh sách nhân viên
- Thêm mới nhân viên
- Sửa thông tin nhân viên
- Xóa nhân viên
- Hiển thị thông tin phòng ban của nhân viên

## Giao diện

- Sử dụng Bootstrap 5 cho responsive design
- Bootstrap Icons cho các icon
- Giao diện hiện đại và chuyên nghiệp

## Cấu trúc URL

- Trang chủ: `http://localhost:8080/Lab6/`
- Phòng ban: `http://localhost:8080/Lab6/departments?action=list`
- Nhân viên: `http://localhost:8080/Lab6/employees?action=list`

## Các thao tác CRUD

### Departments
- List: `GET /departments?action=list`
- Create Form: `GET /departments?action=create`
- Create: `POST /departments` (action=create)
- Edit Form: `GET /departments?action=edit&id={id}`
- Update: `POST /departments` (action=update)
- Delete: `GET /departments?action=delete&id={id}`

### Employees
- List: `GET /employees?action=list`
- Create Form: `GET /employees?action=create`
- Create: `POST /employees` (action=create)
- Edit Form: `GET /employees?action=edit&id={id}`
- Update: `POST /employees` (action=update)
- Delete: `GET /employees?action=delete&id={id}`

## Dependencies

- `mssql-jdbc` (12.8.0.jre8) - SQL Server JDBC Driver
- `jakarta.servlet-api` (6.0.0) - Servlet API cho Tomcat 10.1
- `jakarta.servlet.jsp-api` (3.1.1) - JSP API
- `jakarta.servlet.jsp.jstl-api` (3.0.0) - JSTL API

## Lưu ý

- Đảm bảo SQL Server đang chạy và có thể kết nối
- Kiểm tra thông tin kết nối database trong Jdbc.java
- Database phải được tạo và có dữ liệu mẫu (nếu cần)

