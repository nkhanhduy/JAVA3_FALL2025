-- Tạo database HRM
CREATE DATABASE HRM;
GO

USE HRM;
GO

-- Tạo bảng Departments
CREATE TABLE Departments(
    Id CHAR(3) NOT NULL, --Mã phòng
    Name NVARCHAR(50) NOT NULL, --Tên phòng
    Description NVARCHAR(255) NULL, --Mô tả phòng
    PRIMARY KEY(Id)
);
GO

-- Tạo bảng Employees
CREATE TABLE Employees(
    Id VARCHAR(20) NOT NULL, --Mã nhân viên
    Password NVARCHAR(50) NOT NULL, --Mật khẩu
    Fullname NVARCHAR(50) NOT NULL, --Họ và tên
    Photo NVARCHAR(50) NOT NULL, --Hình ảnh
    Gender BIT NOT NULL, --Giới tính
    Birthday DATE NOT NULL, --Ngày sinh
    Salary FLOAT NOT NULL, --Lương cơ bản
    DepartmentId CHAR(3) NOT NULL, --Mã phòng
    PRIMARY KEY(Id),
    FOREIGN KEY(DepartmentId) REFERENCES Departments(Id)
        ON DELETE CASCADE --Xóa dây chuyền theo DepartmentId
        ON UPDATE CASCADE --Sửa dây chuyền theo DepartmentId
);
GO

-- Thêm dữ liệu mẫu cho Departments
INSERT INTO Departments(Id, Name, Description) VALUES
('IT', N'Công Nghệ Thông Tin', N'Phòng ban phụ trách công nghệ thông tin'),
('HR', N'Nhân Sự', N'Phòng ban quản lý nhân sự'),
('MK', N'Marketing', N'Phòng ban tiếp thị và quảng cáo'),
('FN', N'Tài Chính', N'Phòng ban quản lý tài chính');
GO

-- Thêm dữ liệu mẫu cho Employees
INSERT INTO Employees(Id, Password, Fullname, Photo, Gender, Birthday, Salary, DepartmentId) VALUES
('NV001', '123456', N'Nguyễn Văn A', 'avatar1.jpg', 1, '1990-01-15', 15000000, 'IT'),
('NV002', '123456', N'Trần Thị B', 'avatar2.jpg', 0, '1992-05-20', 12000000, 'HR'),
('NV003', '123456', N'Lê Văn C', 'avatar3.jpg', 1, '1988-08-10', 18000000, 'MK'),
('NV004', '123456', N'Phạm Thị D', 'avatar4.jpg', 0, '1995-12-25', 10000000, 'FN');
GO

-- Stored Procedures cho Departments

-- Thêm mới: {CALL spInsert(?, ?, ?)}
CREATE PROCEDURE spInsert
    @Id CHAR(3),
    @Name NVARCHAR(50),
    @Description NVARCHAR(255)
AS BEGIN
    INSERT INTO Departments(Id, Name, Description)
    VALUES(@Id, @Name, @Description)
END
GO

-- Cập nhật: {CALL spUpdate(?, ?, ?)}
CREATE PROCEDURE spUpdate
    @Id CHAR(3),
    @Name NVARCHAR(50),
    @Description NVARCHAR(255)
AS BEGIN
    UPDATE Departments
    SET Name = @Name, Description = @Description
    WHERE Id = @Id
END
GO

-- Xóa theo khóa chính: {CALL spDeleteById(?)}
CREATE PROCEDURE spDeleteById
    @Id CHAR(3)
AS BEGIN
    DELETE FROM Departments WHERE Id = @Id
END
GO

-- Truy vấn tất cả: {CALL spSelectAll()}
CREATE PROCEDURE spSelectAll
AS BEGIN
    SELECT * FROM Departments
END
GO

-- Truy vấn theo khóa chính: {CALL spSelectById(?)}
CREATE PROCEDURE spSelectById
    @Id CHAR(3)
AS BEGIN
    SELECT * FROM Departments WHERE Id = @Id
END
GO

